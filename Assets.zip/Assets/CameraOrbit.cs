﻿using UnityEngine;
using UnityEngine.InputSystem; 

public class CameraOrbit : MonoBehaviour
{
    public Transform target;
    public float distance = 40f;
    public float speed = 40f;

    private float currentX = 0.0f;
    private float currentY = 20.0f;

    void Start()
    {
        if (target == null)
        {
            GameObject manager = GameObject.Find("StarManager");
            if (manager != null) target = manager.transform;
        }
    }

    void LateUpdate()
    {
        if (target == null || Keyboard.current == null) return;

        
        if (Keyboard.current.rightArrowKey.isPressed) currentX += speed * Time.deltaTime;
        if (Keyboard.current.leftArrowKey.isPressed) currentX -= speed * Time.deltaTime;
        if (Keyboard.current.upArrowKey.isPressed) currentY += speed * Time.deltaTime;
        if (Keyboard.current.downArrowKey.isPressed) currentY -= speed * Time.deltaTime;

        currentY = Mathf.Clamp(currentY, -80f, 80f);

        
        if (Keyboard.current.wKey.isPressed) distance -= 15f * Time.deltaTime;
        if (Keyboard.current.sKey.isPressed) distance += 15f * Time.deltaTime;
        distance = Mathf.Clamp(distance, 5f, 150f);

        Quaternion rotation = Quaternion.Euler(currentY, currentX, 0);
        Vector3 direction = new Vector3(0, 0, -distance);

        transform.position = target.position + rotation * direction;
        transform.LookAt(target.position);
    }
}