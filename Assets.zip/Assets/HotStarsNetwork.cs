using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class HotStarsNetwork : MonoBehaviour
{
    public string csvFileName = "gaia_data";
    private float sphereRadius = 15f;
    private List<HotStarData> hotStars = new List<HotStarData>();
    private List<GameObject> pinkLines = new List<GameObject>();
    private Material pinkMaterial;
    private bool areLinesVisible = false;

    struct HotStarData
    {
        public Vector3 position;
        public float temperature;
    }

    void Start()
    {
        
        StarVisualizer visualizer = FindFirstObjectByType<StarVisualizer>();
        if (visualizer != null)
        {
            sphereRadius = visualizer.sphereRadius;
        }

        
        pinkMaterial = new Material(Shader.Find("Unlit/Color"));
        pinkMaterial.color = new Color(1.0f, 0.08f, 0.57f); // Deep Pink

        
        TextAsset csvFile = Resources.Load<TextAsset>(csvFileName);
        if (csvFile == null) return;

        string[] rows = csvFile.text.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        string[] headers = rows[0].Split(',');

        
        int tempIdx = Array.IndexOf(headers, "Mass (in solar masses)");
        int raIdx = Array.IndexOf(headers, "Right Ascension");
        int decIdx = Array.IndexOf(headers, "Declination");

        if (tempIdx == -1 || raIdx == -1 || decIdx == -1) return;

        List<HotStarData> allParsedStars = new List<HotStarData>();

        for (int i = 1; i < rows.Length; i++)
        {
            string[] columns = rows[i].Split(',');
            if (columns.Length <= Mathf.Max(tempIdx, raIdx, decIdx)) continue;

            try
            {
                float ra = float.Parse(columns[raIdx], System.Globalization.CultureInfo.InvariantCulture);
                float dec = float.Parse(columns[decIdx], System.Globalization.CultureInfo.InvariantCulture);
                float temp = float.Parse(columns[tempIdx], System.Globalization.CultureInfo.InvariantCulture);

                float raRad = ra * Mathf.Deg2Rad;
                float decRad = dec * Mathf.Deg2Rad;

                float x = sphereRadius * Mathf.Cos(decRad) * Mathf.Cos(raRad);
                float z = sphereRadius * Mathf.Cos(decRad) * Mathf.Sin(raRad);
                float y = sphereRadius * Mathf.Sin(decRad);

                allParsedStars.Add(new HotStarData
                {
                    position = new Vector3(x, y, z),
                    temperature = temp
                });
            }
            catch { }
        }

        
        hotStars = allParsedStars.OrderByDescending(s => s.temperature).Take(100).ToList();
    }

    void OnGUI()
    {
        GUIStyle buttonStyle = new GUIStyle(GUI.skin.button);
        buttonStyle.fontSize = 16;
        buttonStyle.fontStyle = FontStyle.Bold;

        string buttonText = areLinesVisible ? "Ascunde Top 100 Temp" : "Arata Top 100 Temp";

        
        if (GUI.Button(new Rect(10, 105, 550, 40), buttonText, buttonStyle))
        {
            TogglePinkNetwork();
        }
    }

    void TogglePinkNetwork()
    {
        areLinesVisible = !areLinesVisible;

        if (areLinesVisible)
        {
            DrawNetwork();
        }
        else
        {
            ClearPinkLines();
        }
    }

    void DrawNetwork()
    {
        ClearPinkLines();

        if (hotStars.Count < 2) return;

        
        for (int i = 0; i < hotStars.Count - 1; i++)
        {
            GameObject lineObj = new GameObject("PinkHotLine");
            lineObj.transform.SetParent(this.transform);

            LineRenderer lr = lineObj.AddComponent<LineRenderer>();
            lr.material = pinkMaterial;
            lr.startWidth = 0.06f; 
            lr.endWidth = 0.06f;
            lr.positionCount = 2;

            lr.SetPosition(0, hotStars[i].position);
            lr.SetPosition(1, hotStars[i + 1].position);

            pinkLines.Add(lineObj);
        }
    }

    void ClearPinkLines()
    {
        foreach (GameObject line in pinkLines)
        {
            if (line != null) Destroy(line);
        }
        pinkLines.Clear();
    }
}