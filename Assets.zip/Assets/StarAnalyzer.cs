using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class StarAnalyzer : MonoBehaviour
{
    public string csvFileName = "gaia_data";
    private float calculatedAverageDistance = 2.0f;
    private List<AnalysisData> allStars = new List<AnalysisData>();
    private List<GameObject> activeLines = new List<GameObject>();
    private Material lineMaterial;

    private string uiStarName = "Nicio stea selectata";
    private string uiNeighborsCount = "Vecini: -";
    private bool hasSelection = false;

    struct AnalysisData
    {
        public string id;
        public Vector3 position;
    }

    void Start()
    {
        float currentRadius = 15f;
        StarVisualizer visualizer = FindFirstObjectByType<StarVisualizer>();
        if (visualizer != null)
        {
            currentRadius = visualizer.sphereRadius;
        }

        TextAsset csvFile = Resources.Load<TextAsset>(csvFileName);
        if (csvFile == null) return;

        string[] rows = csvFile.text.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        string[] headers = rows[0].Split(',');

        int idIdx = Array.IndexOf(headers, "source_id");
        int massIdx = Array.IndexOf(headers, "Mass (in solar masses)");
        int raIdx = Array.IndexOf(headers, "Right Ascension");
        int decIdx = Array.IndexOf(headers, "Declination");

        for (int i = 1; i < rows.Length; i++)
        {
            string[] columns = rows[i].Split(',');
            if (columns.Length <= Mathf.Max(idIdx, massIdx, raIdx, decIdx)) continue;

            try
            {
                float ra = float.Parse(columns[raIdx], System.Globalization.CultureInfo.InvariantCulture);
                float dec = float.Parse(columns[decIdx], System.Globalization.CultureInfo.InvariantCulture);

                float raRad = ra * Mathf.Deg2Rad;
                float decRad = dec * Mathf.Deg2Rad;

                float x = currentRadius * Mathf.Cos(decRad) * Mathf.Cos(raRad);
                float z = currentRadius * Mathf.Cos(decRad) * Mathf.Sin(raRad);
                float y = currentRadius * Mathf.Sin(decRad);

                allStars.Add(new AnalysisData
                {
                    id = columns[idIdx],
                    position = new Vector3(x, y, z)
                });
            }
            catch { }
        }

        float totalDistance = 0f;
        int distanceCount = 0;

        for (int i = 0; i < allStars.Count; i++)
        {
            for (int j = i + 1; j < allStars.Count; j++)
            {
                totalDistance += Vector3.Distance(allStars[i].position, allStars[j].position);
                distanceCount++;
            }
        }

        if (distanceCount > 0)
        {
            calculatedAverageDistance = (totalDistance / distanceCount) * 0.15f;
            Debug.LogWarning("[StarAnalyzer] Distanta medie calculata automat este: " + calculatedAverageDistance);
        }

        lineMaterial = new Material(Shader.Find("Unlit/Color"));
        lineMaterial.color = Color.white;
    }

    void Update()
    {
        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            Ray ray = Camera.main.ScreenPointToRay(Mouse.current.position.ReadValue());
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                ClearOldLines();

                string clickedStarName = hit.collider.gameObject.name;
                Vector3 selectedPosition = hit.collider.transform.position;

                ShowNeighborsForPosition(selectedPosition, clickedStarName);
            }
        }
    }

    void ShowNeighborsForPosition(Vector3 targetPosition, string starName)
    {
        int neighborCount = 0;

        for (int i = 0; i < allStars.Count; i++)
        {
            float dist = Vector3.Distance(targetPosition, allStars[i].position);

            if (dist > 0.01f && dist <= calculatedAverageDistance)
            {
                neighborCount++;

                GameObject lineObj = new GameObject("ConnectionLine");
                lineObj.transform.SetParent(this.transform);

                LineRenderer lr = lineObj.AddComponent<LineRenderer>();
                lr.material = lineMaterial;
                lr.startWidth = 0.04f;
                lr.endWidth = 0.04f;
                lr.positionCount = 2;
                lr.SetPosition(0, targetPosition);
                lr.SetPosition(1, allStars[i].position);

                activeLines.Add(lineObj);
            }
        }

        uiStarName = "Nume: " + starName;
        uiNeighborsCount = "Vecini detectati: " + neighborCount + " (Raza: " + calculatedAverageDistance.ToString("F2") + ")";
        hasSelection = true;

        Debug.Log("[Selectie] " + starName + " are " + neighborCount + " vecini in raza de " + calculatedAverageDistance);
    }

    void ClearOldLines()
    {
        foreach (GameObject line in activeLines)
        {
            if (line != null) Destroy(line);
        }
        activeLines.Clear();
    }

    void OnGUI()
    {
        
        GUI.Box(new Rect(10, 10, 550, 85), "");

        
        GUIStyle textStyle = new GUIStyle();
        textStyle.normal.textColor = Color.white;
        textStyle.fontSize = 22;
        textStyle.fontStyle = FontStyle.Bold;

        if (hasSelection)
        {
            GUI.Label(new Rect(25, 18, 520, 30), uiStarName, textStyle);
            GUI.Label(new Rect(25, 48, 520, 30), uiNeighborsCount, textStyle);
        }
        else
        {
            GUI.Label(new Rect(25, 30, 520, 30), "Click pe o stea...", textStyle);
        }
    }
}