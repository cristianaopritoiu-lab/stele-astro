﻿using System;
using UnityEngine;

public class StarVisualizer : MonoBehaviour
{
    public string csvFileName = "gaia_data";
    public GameObject starPrefab;
    public float sphereRadius = 15f;

    void Start()
    {
        TextAsset csvFile = Resources.Load<TextAsset>(csvFileName);
        if (csvFile == null) return;

        
        string[] rows = csvFile.text.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        string[] headers = rows[0].Split(',');

        int idIdx = Array.IndexOf(headers, "source_id");
        int massIdx = Array.IndexOf(headers, "Mass (in solar masses)");
        int raIdx = Array.IndexOf(headers, "Right Ascension");
        int decIdx = Array.IndexOf(headers, "Declination");

        for (int i = 1; i < rows.Length; i++)
        {
            string[] columns = rows[i].Split(',');
            if (columns.Length <= Mathf.Max(idIdx, massIdx, raIdx, decIdx)) continue;

            try
            {
                string starId = columns[idIdx];
                float mass = float.Parse(columns[massIdx], System.Globalization.CultureInfo.InvariantCulture);
                float ra = float.Parse(columns[raIdx], System.Globalization.CultureInfo.InvariantCulture);
                float dec = float.Parse(columns[decIdx], System.Globalization.CultureInfo.InvariantCulture);

                float raRad = ra * Mathf.Deg2Rad;
                float decRad = dec * Mathf.Deg2Rad;

                float x = sphereRadius * Mathf.Cos(decRad) * Mathf.Cos(raRad);
                float z = sphereRadius * Mathf.Cos(decRad) * Mathf.Sin(raRad);
                float y = sphereRadius * Mathf.Sin(decRad);

                Vector3 starPosition = new Vector3(x, y, z);
                GameObject newStar = Instantiate(starPrefab, starPosition, Quaternion.identity, this.transform);
                newStar.name = "Star_" + starId;

                Renderer starRenderer = newStar.GetComponent<Renderer>();
                if (starRenderer != null)
                {
                    
                    Material unlitMaterial = new Material(Shader.Find("Unlit/Color"));

                    
                    unlitMaterial.color = Color.Lerp(Color.red, Color.cyan, (mass - 0.5f) / 1.5f);

                    starRenderer.material = unlitMaterial;
                }
            }
            catch { }
        }
    }
}